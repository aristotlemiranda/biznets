package sg.com.amm.poc.demoapp.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import sg.com.amm.poc.demoapp.wrapper.CachedBodyHttpServletRequest;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component
public class CustomInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // Ensure the request is wrapped properly
        if (!(request instanceof CachedBodyHttpServletRequest)) {
            request = new CachedBodyHttpServletRequest(request);
        }

        // Read request headers
        String customHeader = request.getHeader("X-Header-HMAC");
        System.out.println("Interceptor: Custom-Header = " + customHeader);

        if (customHeader == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return false;
        }

        // Read and validate request body
        String body = getRequestBody((CachedBodyHttpServletRequest) request);
        System.out.println("Interceptor: Request body read = " + body);

        if (validateRequestBody(body)) {
            System.out.println("Interceptor: Request body is valid");
            return true;
        } else {
            System.out.println("Interceptor: Invalid request body");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            return false;
        }
    }

    private String getRequestBody(CachedBodyHttpServletRequest request) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        try(BufferedReader reader = request.getReader()) {
            String line;
            while( (line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        }
        return stringBuilder.toString();
    }

    private boolean validateRequestBody(String body) {
        // Add your custom validation logic here
        System.out.println("Interceptor: Validating request body");
        if(!body.contains("SAMPLE")) return false;
        return body != null && !body.trim().isEmpty();
    }
}
