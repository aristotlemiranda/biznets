package sg.com.amm.poc.demoapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController {

    @PostMapping("/hello")
    public ResponseEntity<String> hello(@RequestBody String requestBody) {

        return new ResponseEntity<>(requestBody, HttpStatus.OK);
    }
}
