package sg.com.amm.poc.demoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
