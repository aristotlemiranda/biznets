package sg.com.amm.sns.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sg.com.amm.sns.demo.service.SmsService;

@RestController
@RequestMapping("/api/sendsms")
public class SendSMSController {

    @Autowired
    SmsService smsService;

    @Value("${aws.accessKeyId}")
    private String accessKeyId;

    @PostMapping("post")
    public ResponseEntity<String> post(@RequestParam("number") String number, @RequestParam("message") String message) {
        try {
            smsService.sendSms("+65"+number, message);
            return ResponseEntity.accepted().body("SMS sent to:" + number);
        }catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error sending SMS: " + e.getMessage());
        }
    }

    @GetMapping("test")
    public String test() {
        System.out.println("accessKeyId = " + accessKeyId);
        return "OK";
    }
}
