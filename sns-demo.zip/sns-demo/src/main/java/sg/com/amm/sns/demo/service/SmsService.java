package sg.com.amm.sns.demo.service;


import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SmsService {

    @Autowired
    AmazonSNS amazonSNSClient;


    public void sendSms(String phoneNumber, String message) {
        PublishRequest publishRequest = new PublishRequest()
                .withMessage(message)
                .withPhoneNumber(phoneNumber);
        PublishResult publishResult = amazonSNSClient.publish(publishRequest);
        System.out.println("Message ID: " + publishResult.getMessageId());
    }
}
