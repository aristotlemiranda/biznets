package sg.com.amm.sns.demo;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SnsConfig {

    @Value("${aws.accessKeyId}")
    String accessKeyId;

    @Value("${aws.secretKey}")
    String secretKey;

    @Value("${aws.region}")
    String region;
    @Bean
   public AmazonSNS amazonSNSClient() {
        System.out.println("accessKeyId = " + accessKeyId);
        System.out.println("secretKey = " + secretKey);
        System.out.println("region = " + region);
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKeyId, secretKey);

        return AmazonSNSClientBuilder.standard()
                .withRegion(region)
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();
   }
}
